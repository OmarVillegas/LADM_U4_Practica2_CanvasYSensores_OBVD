package mx.edu.ittepic.ladm_u4_practica2_canvasysensores

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Color.YELLOW
import android.graphics.Paint
import android.view.View

class Lienzo (p:MainActivity) : View(p) {
var puntero = p
    var Dia = true
    var posicionX = 600f
    var posicionY = 1700f

    override fun onDraw(c:Canvas) {
        super.onDraw(c)
        val p = Paint()

        if (Dia ==true){
            //---------------------------------SOL-----------------------------//
            p.color = Color.YELLOW
            c.drawCircle(200f, 300f, 150f,p)

            //RECTANGULO SOL ABAJO
            p.color = Color.YELLOW
            c.drawRect(150f, 650f, 250f, 250f,p)
            //RECTANGULO ARRIBA
            p.color=Color.YELLOW
            c.drawRect(150f, 250f, 250f, 50f,p)
            //RECTANGULO DERECHO
            p.color=Color.YELLOW
            c.drawRect(150f, 150f, 150f, 50f,p)
            //RECTANGULO IZQUIERDO
            p.color=Color.YELLOW
            c.drawRect(5f, 250f, 550f, 350f,p)
            //---------------------------------------------------------------//

            //NUBE ABAJO IZQUIERDA
            p.color=Color.rgb(143,192,192)
            c.drawCircle(170f,800f,100f, p)
            p.color=Color.rgb(143,192,192)
            c.drawCircle(270f,790f,100f, p)

            //NUBE ARRIBA DERECHA
            p.color=Color.rgb(143,192,192)
            c.drawCircle(570f,500f,100f, p)
            p.color=Color.rgb(143,192,192)
            c.drawCircle(700f,490f,100f, p)
            p.color=Color.rgb(143,192,192)
            c.drawCircle(800f,500f,100f, p)
        }else{
            c.drawRGB(38,96,169)

        //-----------------------------NOCHE----------------------------//

            //LUNA
            p.color = Color.WHITE
            c.drawCircle(200f,300f, 150f,p)

            p.color=Color.rgb(38,96,165)
            c.drawCircle(350f,300f,150f, p)

            p.color=Color.rgb(38,96,165)
            c.drawCircle(1050f,100f,150f, p)



            //NUBE DE NOCHE (ARRIBA)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(370f,200f,100f, p)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(500f,190f,100f, p)

            //NUBE DE NOCHE (ENMEDIO)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(570f,500f,100f, p)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(700f,490f,100f, p)

            //NUBE DE NOCHE ( ABAJO DERECHA)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(770f,800f,100f, p)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(900f,790f,100f, p)

            //NUBE DE NOCHE ( ABAJO IZQUIERDA)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(370f,900f,100f, p)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(500f,890f,100f, p)

            //NUBE DE NOCHE (ABAJO LUNA)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(170f,700f,100f, p)
            p.color=Color.rgb(24,64,97)
            c.drawCircle(300f,690f,100f, p)

        }
        //TRONCO ARBOL IZQUIERDO
        p.color=Color.rgb(95,59,23)
        c.drawRect(415f,1450f,255f, 1800f, p)

        //TRONCO ARBOL DERECHO
        p.color=Color.rgb(95,59,23)
        c.drawRect(915f,1250f,755f, 1655f, p)

        //HOJAS ARBOL IZQUIEROD
        p.color=Color.rgb(66,105,80)
        c.drawCircle(255f,1250f,100f, p)
        p.color=Color.rgb(66,105,80)
        c.drawCircle(280f,1390f,100f, p)
        p.color=Color.rgb(66,105,80)
        c.drawCircle(355f,1250f,100f, p)
        p.color=Color.rgb(66,105,80)
        c.drawCircle(380f,1390f,100f, p)
        p.color=Color.rgb(66,105,80)
        c.drawCircle(455f,1250f,100f, p)

        //HOJAS ARBOL DERECHO
        p.color=Color.rgb(66,105,80)
        c.drawCircle(355f,1150f,100f, p)
        p.color=Color.rgb(66,105,80)
        c.drawCircle(820f,1150f,250f, p)

        c.drawBitmap(BitmapFactory.decodeResource(resources, R.drawable.esqueleto), posicionX, posicionY, p)
    }
}